using System.Windows;

namespace Regestrasia;

public partial class App : Application
{
}
