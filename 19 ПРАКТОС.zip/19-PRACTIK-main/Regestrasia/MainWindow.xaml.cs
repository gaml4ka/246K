using System.Windows;
using System.Windows.Controls;

namespace Regestrasia;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void RegisterButton_Click(object sender, RoutedEventArgs e)
    {
        if (!TryValidateForm(out string error))
        {
            MessageBox.Show(error);
            return;
        }

        MessageBox.Show("Поздравляем! Регистрация прошла успешно");
    }

    // Проверяет заполненность полей и наличие «@» в Email
    private bool TryValidateForm(out string error)
    {
        if (string.IsNullOrWhiteSpace(FullNameBox.Text) || string.IsNullOrWhiteSpace(MailBox.Text))
        {
            error = "Поля не заполнены";
            return false;
        }

        if (!MailBox.Text.Contains('@'))
        {
            error = "Ошибка в Email";
            return false;
        }

        error = string.Empty;
        return true;
    }

    private void RoleSelected(object sender, RoutedEventArgs e)
    {
        if (sender is RadioButton role)
            MessageBox.Show($"Выбрана роль: {role.Content}");
    }

    private void RulesCheck_Checked(object sender, RoutedEventArgs e) =>
        MessageBox.Show("Пользователь согласился с правилами!");

    private void RulesCheck_Unchecked(object sender, RoutedEventArgs e) =>
        MessageBox.Show("Пользователь убрал согласие.");
}
