using System.Windows;

namespace Shopping;

public partial class App : Application
{
}
