using System.Windows;

namespace Shopping;

public partial class MainWindow : Window
{
    // Остатки на складе и названия товаров, добавленных в корзину
    private readonly List<Product> _stock = new()
    {
        new Product { Name = "Смартфон",           Quantity = 10 },
        new Product { Name = "Ноутбук",            Quantity = 3 },
        new Product { Name = "Наушники",           Quantity = 25 },
        new Product { Name = "Монитор",            Quantity = 5 },
        new Product { Name = "Мышь беспроводная",  Quantity = 40 },
        new Product { Name = "Клавиатура",         Quantity = 15 },
        new Product { Name = "Повербанк",          Quantity = 18 }
    };

    private readonly List<string> _cart = new();

    public MainWindow()
    {
        InitializeComponent();
        ShowAvailableProducts();
    }

    // Показывает в списке только товары, которые есть в наличии
    private void ShowAvailableProducts()
    {
        StockList.Items.Clear();

        foreach (Product product in _stock.Where(p => p.Quantity > 0))
            StockList.Items.Add(product);
    }

    private void Add_Click(object sender, RoutedEventArgs e)
    {
        if (StockList.SelectedItem is not Product selected)
        {
            MessageBox.Show("Выберите товар из списка.");
            return;
        }

        Product? stockItem = _stock.FirstOrDefault(p => p.Name == selected.Name);
        if (stockItem is null || stockItem.Quantity <= 0)
        {
            MessageBox.Show("Товар закончился.");
            ShowAvailableProducts();
            return;
        }

        stockItem.Quantity--;
        _cart.Add(selected.Name);

        ShowAvailableProducts();
        CartList.Items.Add($"{selected.Name} (1 шт.)");
    }

    private void Checkout_Click(object sender, RoutedEventArgs e)
    {
        if (_cart.Count == 0)
        {
            MessageBox.Show("Корзина пуста.");
            return;
        }

        IEnumerable<string> orderLines = _cart
            .GroupBy(name => name)
            .Select(group => $"{group.Key} — {group.Count()} шт.");

        string summary = "Ваш заказ:\n\n" + string.Join("\n", orderLines);
        MessageBox.Show(summary, "Оформление заказа");

        _cart.Clear();
        CartList.Items.Clear();
    }
}
