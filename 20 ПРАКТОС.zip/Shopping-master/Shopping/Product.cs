namespace Shopping;

internal class Product
{
    public string Name { get; set; } = string.Empty;
    public int Quantity { get; set; }

    public override string ToString() => $"{Name} (осталось: {Quantity})";
}
