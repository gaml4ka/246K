using System.Windows;

namespace pr_21_246k;

public partial class App : Application
{
}
