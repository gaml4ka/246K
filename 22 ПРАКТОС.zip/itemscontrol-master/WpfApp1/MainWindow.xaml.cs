using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfApp1;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<Product> _products = new()
    {
        new Product { Name = "Товар 1", Count = 1,   Price = 123,   Rating = 4, Description = "Офигенный товар 1", Cover = "/images/vgpek.png" },
        new Product { Name = "Товар 2", Count = 64,  Price = 1243,  Rating = 5, Description = "Офигенный товар 2", Cover = "/images/cat1.png" },
        new Product { Name = "Товар 3", Count = 346, Price = 12533, Rating = 2, Description = "Офигенный товар 3", Cover = "/images/cat2.png" },
        new Product { Name = "Товар 4", Count = 3,   Price = 1287,  Rating = 5, Description = "Офигенный товар 4", Cover = "/images/chel.png" },
        new Product { Name = "Товар 5", Count = 87,  Price = 19,    Rating = 1, Description = "Офигенный товар 5", Cover = "/images/cat2.png" }
    };

    // Товар, выбранный щелчком по карточке
    private Product _selectedProduct = new();

    public MainWindow()
    {
        InitializeComponent();
        ProductList.ItemsSource = _products;
    }

    private void Add_Click(object sender, RoutedEventArgs e) => _products.Add(ReadProductFromForm());

    private void ProductCard_MouseDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: Product product })
        {
            FillForm(product);
            _selectedProduct = product;
        }
    }

    private void Del_Click(object sender, RoutedEventArgs e)
    {
        MessageBoxResult answer = MessageBox.Show(
            $"Вы точно хотите удалить {_selectedProduct.Name} ?",
            "Подтверждение удаления",
            MessageBoxButton.YesNo,
            MessageBoxImage.Question);

        if (answer == MessageBoxResult.Yes)
        {
            _products.Remove(_selectedProduct);
            txtName.Clear();
        }
    }

    private void Sell_Click(object sender, RoutedEventArgs e) => _selectedProduct.Count--;

    // Собирает товар из значений полей формы
    private Product ReadProductFromForm() => new()
    {
        Name = txtName.Text,
        Count = Convert.ToInt32(txtCount.Text),
        Description = txtDesc.Text,
        Price = Convert.ToInt32(txtPrice.Text),
        Rating = Convert.ToInt32(txtRating.Text),
        Cover = txtImage.Text
    };

    // Переносит данные товара в поля формы
    private void FillForm(Product product)
    {
        txtName.Text = product.Name;
        txtCount.Text = product.Count.ToString();
        txtDesc.Text = product.Description;
        txtImage.Text = product.Cover;
        txtPrice.Text = product.Price.ToString();
        txtRating.Text = product.Rating.ToString();
    }
}
