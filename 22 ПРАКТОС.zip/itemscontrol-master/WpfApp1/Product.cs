namespace WpfApp1;

internal class Product
{
    public string Name { get; set; } = string.Empty;
    public int Price { get; set; }
    public int Count { get; set; }
    public string Description { get; set; } = string.Empty;
    public int Rating { get; set; }
    public string Cover { get; set; } = string.Empty;
}
