using System.Windows;

namespace _246k_pr23;

public partial class MainWindow : Window
{
    private readonly User _person = new();

    public MainWindow()
    {
        InitializeComponent();
        DataContext = _person;
    }

    private void Reg_Click(object sender, RoutedEventArgs e) =>
        MessageBox.Show($"Зарегистрирован: \n{_person.Name}\n{_person.Email}\n{_person.Age} лет");
}
