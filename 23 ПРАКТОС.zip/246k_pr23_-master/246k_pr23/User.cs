using System.ComponentModel;

namespace _246k_pr23;

public class User : IDataErrorInfo
{
    private const int MinAge = 0;
    private const int MaxAge = 120;

    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public int Age { get; set; }

    // Общая ошибка объекта не используется — проверяется каждое свойство отдельно
    public string? Error => null;

    public string? this[string columnName] => columnName switch
    {
        nameof(Name) => ValidateName(),
        nameof(Age) => ValidateAge(),
        nameof(Email) => ValidateEmail(),
        _ => null
    };

    private string? ValidateName() =>
        string.IsNullOrWhiteSpace(Name) ? "Имя не может быть пустым" : null;

    private string? ValidateAge() =>
        Age is < MinAge or > MaxAge ? $"Возраст должен быть от {MinAge} до {MaxAge}" : null;

    private string? ValidateEmail()
    {
        if (string.IsNullOrWhiteSpace(Email))
            return "Email не может быть пустым";

        // Должна быть «@», а после неё — хотя бы одна точка
        int atIndex = Email.IndexOf('@');
        int dotIndex = Email.IndexOf('.');

        return atIndex == -1 || dotIndex == -1 || dotIndex < atIndex
            ? "Email некорректен"
            : null;
    }
}
