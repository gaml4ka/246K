using System.Windows;

namespace _246k_json;

public partial class App : Application
{
}
