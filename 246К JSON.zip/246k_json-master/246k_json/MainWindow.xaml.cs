using System.Collections.ObjectModel;
using System.IO;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Unicode;
using System.Windows;

namespace _246k_json;

public partial class MainWindow : Window
{
    private const string FileName = "students.json";

    // Отступы в JSON и корректное отображение кириллицы (без \uXXXX)
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        Encoder = JavaScriptEncoder.Create(UnicodeRanges.All)
    };

    private ObservableCollection<Student> _students = new();

    public MainWindow()
    {
        InitializeComponent();
        tableStudent.ItemsSource = _students;
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        File.WriteAllText(FileName, JsonSerializer.Serialize(_students, JsonOptions));
        MessageBox.Show("Данные сохранены!");
    }

    private void Load_Click(object sender, RoutedEventArgs e)
    {
        string json = File.ReadAllText(FileName);

        _students = JsonSerializer.Deserialize<ObservableCollection<Student>>(json)
                    ?? new ObservableCollection<Student>();
        tableStudent.ItemsSource = _students;
    }
}
