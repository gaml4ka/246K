using System.Windows;

namespace Reminder;

public partial class App : Application
{
}
