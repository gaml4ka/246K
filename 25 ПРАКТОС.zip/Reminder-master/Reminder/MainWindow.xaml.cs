using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Threading;

namespace Reminder;

public partial class MainWindow : Window
{
    // Разделитель полей в текстовом файле: час%%минута%%текст%%показано
    private const string FieldSeparator = "%%";

    private readonly ObservableCollection<Reminders> _reminders = new();
    private readonly DispatcherTimer _timer;

    public MainWindow()
    {
        InitializeComponent();

        _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(10) };
        _timer.Tick += Timer_Tick;
    }

    // Раз в 10 секунд проверяет, не наступило ли время какого-либо напоминания
    private void Timer_Tick(object? sender, EventArgs e)
    {
        DateTime now = DateTime.Now;

        foreach (Reminders reminder in _reminders)
        {
            if (reminder.Hour == now.Hour && reminder.Minute == now.Minute && !reminder.IsShown)
            {
                MessageBox.Show($"{reminder.Hour}:{reminder.Minute} - {reminder.Text}",
                    "Напоминание", MessageBoxButton.OK, MessageBoxImage.Information);
                reminder.IsShown = true;
            }
        }

        // Обновляем таблицу, чтобы отразить изменённый флаг «Показать»
        lbNames.ItemsSource = null;
        lbNames.ItemsSource = _reminders;
    }

    private void Add_Click(object sender, RoutedEventArgs e)
    {
        if (int.TryParse(txtHour.Text, out int hour) && int.TryParse(txtMinute.Text, out int minute))
        {
            _reminders.Add(new Reminders
            {
                Hour = hour,
                Minute = minute,
                Text = txtText.Text,
                IsShown = false
            });
        }
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new SaveFileDialog { Filter = "Текстовые файлы (*.txt)|*.txt" };

        if (dialog.ShowDialog() == true)
        {
            File.WriteAllLines(dialog.FileName, _reminders.Select(FormatReminder));
            MessageBox.Show("Файл сохранён!");
        }
    }

    private void Open_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*" };

        if (dialog.ShowDialog() == true)
        {
            foreach (string line in File.ReadAllLines(dialog.FileName))
                _reminders.Add(ParseReminder(line));

            lbNames.ItemsSource = _reminders;
            _timer.Start();
        }
    }

    private void Del_Click(object sender, RoutedEventArgs e)
    {
        if (lbNames.SelectedItem is Reminders selected)
            _reminders.Remove(selected);
    }

    private static string FormatReminder(Reminders r) =>
        string.Join(FieldSeparator, r.Hour, r.Minute, r.Text, r.IsShown);

    private static Reminders ParseReminder(string line)
    {
        string[] parts = line.Split(FieldSeparator);

        return new Reminders
        {
            Hour = Convert.ToInt32(parts[0]),
            Minute = Convert.ToInt32(parts[1]),
            Text = parts[2],
            IsShown = Convert.ToBoolean(parts[3])
        };
    }
}
