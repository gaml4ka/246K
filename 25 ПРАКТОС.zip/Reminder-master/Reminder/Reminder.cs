namespace Reminder;

public class Reminders
{
    public int Hour { get; set; }
    public int Minute { get; set; }
    public string Text { get; set; } = string.Empty;
    public bool IsShown { get; set; }
}
