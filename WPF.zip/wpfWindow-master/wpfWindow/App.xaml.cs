using System.Windows;

namespace wpfWindow;

public partial class App : Application
{
}
