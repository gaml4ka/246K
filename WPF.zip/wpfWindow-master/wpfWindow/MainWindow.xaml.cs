using System.Windows;
using System.Windows.Controls;
using wpfWindow.pages;

namespace wpfWindow;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        NavigateTo(new MainPage());
    }

    private void NavigateTo(Page page) => MainFrame.Navigate(page);

    private void ShowMain_Click(object sender, RoutedEventArgs e) => NavigateTo(new MainPage());

    private void ShowCatalog_Click(object sender, RoutedEventArgs e) => NavigateTo(new CatalogPage());

    private void ShowDesc_Click(object sender, RoutedEventArgs e) => NavigateTo(new DescPage());

    private void Back_Click(object sender, RoutedEventArgs e)
    {
        if (MainFrame.CanGoBack)
            MainFrame.GoBack();
    }

    private void Forward_Click(object sender, RoutedEventArgs e)
    {
        if (MainFrame.CanGoForward)
            MainFrame.GoForward();
    }
}
