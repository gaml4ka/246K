using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using wpfWindow.windows;

namespace wpfWindow.pages;

public partial class CatalogPage : Page
{
    private readonly ObservableCollection<Book> _books = new()
    {
        new Book { Title = "Мастер и Маргарита", Author = "М. Булгаков", Year = 1967 },
        new Book { Title = "Три товарища", Author = "Э.М. Ремарк", Year = 1936 },
        new Book { Title = "Пикник на обочине", Author = "Стругацкие", Year = 1972 }
    };

    public CatalogPage()
    {
        InitializeComponent();
        dataBooks.ItemsSource = _books;
    }

    private void Add_Click(object sender, RoutedEventArgs e)
    {
        var newBook = new Book();
        var dialog = new AddBookWindow { DataContext = newBook };

        if (dialog.ShowDialog() == true)
            _books.Add(newBook);
    }

    private void Del_Click(object sender, RoutedEventArgs e)
    {
        if (dataBooks.SelectedItem is Book selected)
            _books.Remove(selected);
    }
}
