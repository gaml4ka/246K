using System.Windows.Controls;

namespace wpfWindow.pages;

public partial class DescPage : Page
{
    public DescPage()
    {
        InitializeComponent();
    }
}
