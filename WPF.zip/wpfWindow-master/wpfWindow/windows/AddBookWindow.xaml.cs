using System.Windows;

namespace wpfWindow.windows;

public partial class AddBookWindow : Window
{
    public AddBookWindow()
    {
        InitializeComponent();
    }

    private void Add_Click(object sender, RoutedEventArgs e) => DialogResult = true;

    private void Cancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
}
